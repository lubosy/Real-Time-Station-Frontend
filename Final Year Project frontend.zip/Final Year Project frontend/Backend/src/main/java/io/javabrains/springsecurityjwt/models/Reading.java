package io.javabrains.springsecurityjwt.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Reading {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Long id;
    private Double temperature;
    private Double gnd_temperature;
    private Double humidity;
    private Double wind_speed;
    private Double wind_direction;

    public Reading() {
    }

    public Reading(Double temperature,
                   Double gnd_temperature,
                   Double humidity,
                   Double wind_speed,
                   Double wind_direction,
                   Double rain) {
        this.temperature = temperature;
        this.gnd_temperature = gnd_temperature;
        this.humidity = humidity;
        this.wind_speed = wind_speed;
        this.wind_direction = wind_direction;
        this.rain = rain;
    }

    public Reading(Long id,
                   Double temperature,
                   Double gnd_temperature,
                   Double humidity,
                   Double wind_speed,
                   Double wind_direction,
                   Double rain) {
        this.id = id;
        this.temperature = temperature;
        this.gnd_temperature = gnd_temperature;
        this.humidity = humidity;
        this.wind_speed = wind_speed;
        this.wind_direction = wind_direction;
        this.rain = rain;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getTemperature() {
        return temperature;
    }

    public void setTemperature(Double temperature) {
        this.temperature = temperature;
    }

    public Double getGnd_temperature() {
        return gnd_temperature;
    }

    public void setGnd_temperature(Double gnd_temperature) {
        this.gnd_temperature = gnd_temperature;
    }

    public Double getHumidity() {
        return humidity;
    }

    public void setHumidity(Double humidity) {
        this.humidity = humidity;
    }

    public Double getWind_speed() {
        return wind_speed;
    }

    public void setWind_speed(Double wind_speed) {
        this.wind_speed = wind_speed;
    }

    public Double getWind_direction() {
        return wind_direction;
    }

    public void setWind_direction(Double wind_direction) {
        this.wind_direction = wind_direction;
    }

    public Double getRain() {
        return rain;
    }

    public void setRain(Double rain) {
        this.rain = rain;
    }

    private Double rain;
}
